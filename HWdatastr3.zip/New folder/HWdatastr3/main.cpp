#include <iostream>
#include <vector>
#include <queue>
#include <tuple>

using namespace std;
vector<int> mergeKSortedArrays(const vector<vector<int>>& arrays) {
    vector<int> result;

    priority_queue<tuple<int, int, int>, vector<tuple<int, int, int>>, greater<>> minHeap;

    for (int i = 0; i < arrays.size(); i++) {
        if (!arrays[i].empty()) {
            minHeap.emplace(arrays[i][0], i, 0);
        }
    }
    while (!minHeap.empty()) {
        auto [val, arrayIndex, valueIndex] = minHeap.top();
        minHeap.pop();

        result.push_back(val);
        if (valueIndex + 1 < arrays[arrayIndex].size()) {
            minHeap.emplace(arrays[arrayIndex][valueIndex + 1], arrayIndex, valueIndex + 1);
        }
    }

    return result;
}

int main() {
    int k;
    cout << "Enter the number of arrays: ";
    cin >> k;

    if (k <= 0) {
        cout << "Invalid input. Number of arrays must be greater than 0." << endl;
        return 1;
    }

    vector<vector<int>> arrays(k);
    cout << "Enter the arrays (space-separated integers, one array per line):" << endl;
    cin.ignore(); // To ignore any leftover newline characters

    for (int i = 0; i < k; i++) {
        string line;
        getline(cin, line);

        int num;
        vector<int> array;
        size_t pos = 0;

        while ((pos = line.find(' ')) != string::npos) {
            num = stoi(line.substr(0, pos));
            array.push_back(num);
            line.erase(0, pos + 1);
        }
        if (!line.empty()) {
            num = stoi(line);
            array.push_back(num);
        }

        arrays[i] = array;
    }

    vector<int> mergedArray = mergeKSortedArrays(arrays);

    cout << "Merged Array: ";
    for (int num : mergedArray) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}
