#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

pair<int, vector<int>> scheduleTasks(vector<pair<int, int>>& tasks) {

    sort(tasks.begin(), tasks.end(), [](const pair<int, int>& a, const pair<int, int>& b) {
        return a.first > b.first;
    });

    int max_deadline = 0;
    for (const auto& task : tasks) {
        max_deadline = max(max_deadline, task.second);
    }
    vector<int> slots(max_deadline + 1, -1);
    int total_profit = 0;
    vector<int> scheduled_tasks;

    for (const auto& task : tasks) {
        int profit = task.first;
        int deadline = task.second;

        for (int i = deadline; i > 0; --i) {
            if (slots[i] == -1) {
                slots[i] = profit;
                total_profit += profit;
                scheduled_tasks.push_back(profit);
                break;
            }
        }
    }
    return {total_profit, scheduled_tasks};
}
int main() {
    int n;
    cout << "Enter the number of tasks: ";
    cin >> n;

    vector<pair<int, int>> tasks(n);

    cout << "Enter profit and deadline for each task:\n";
    for (int i = 0; i < n; i++) {
        cin >> tasks[i].first >> tasks[i].second;
    }

    auto [max_profit, scheduled_tasks] = scheduleTasks(tasks);

    cout << "Maximum Profit: " << max_profit << endl;
    cout << "Scheduled Tasks: ";
    for (int profit : scheduled_tasks) {
        cout << profit << " ";
    }
    cout << endl;
    return 0;
}
